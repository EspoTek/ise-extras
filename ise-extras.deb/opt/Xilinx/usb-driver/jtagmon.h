void __attribute__ ((visibility ("hidden"))) jtagmon(unsigned char tck, unsigned char tms, unsigned char tdi);
